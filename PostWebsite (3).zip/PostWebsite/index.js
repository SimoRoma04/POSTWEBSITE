let express = require('express');
let path = require('path');
let fs = require('fs')
let bodyParser = require('body-parser')
if (!fs.existsSync('./data/data.json')){
  fs.mkdir("./data", (err)=>{})
  fs.writeFile("./data/data.json", "[]", (err)=>{})
}
let app = express();
let myLibrary = require('./myDepetris.js')

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'app_views'))
app.use(bodyParser.urlencoded({ extended: true }))

app.get('/', function(req, res) {
  res.render('pages/index', {
    titoloJSON: "Home",
    currentPage: "Home"
  });
});

app.get('/table', function(req, res) {

  let data = myLibrary.readFile('./data/data.json')

  res.render('pages/table', {
    data: data,
    titoloJSON: "Table",
    currentPage: "Table"
  });
});

app.post('/scrivi', function(req, res) {

  let dataJSON = myLibrary.readFile('./data/data.json')
  let person = {
    name: req.body.name,
    nickname: req.body.nickname,
    content: req.body.content,
  }

  myLibrary.addElementToJSON(dataJSON, person)

  res.redirect('/table');
});

app.listen(8080);