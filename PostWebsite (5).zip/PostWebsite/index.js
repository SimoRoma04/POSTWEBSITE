let express = require('express');
let path = require('path');
let fs = require('fs')
let bodyParser = require('body-parser')
if (!fs.existsSync('./data/data.json')){ /* crea un file JSON se non è gia esistente*/
  fs.mkdir("./data", (err)=>{})
  fs.writeFile("./data/data.json", "[]", (err)=>{})
}
let app = express();
let myLibrary = require('./myDepetris.js') /* richiama myDepetris.js */

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'app_views'))
app.use(bodyParser.urlencoded({ extended: true }))

app.get('/', function(req, res) {/* ti indirizza alla pagina index.ejs */
  res.render('pages/index', {
    titoloJSON: "Home",
    currentPage: "Home"
  });
});

app.get('/table', function(req, res) { /* ti indirizza alla pagina table.ejs */

  let data = myLibrary.readFile('./data/data.json')

  res.render('pages/table', {
    data: data,
    titoloJSON: "Table",
    currentPage: "Table"
  });
});

app.post('/scrivi', function(req, res) { /* crea il post-it prendendo le informazioni date prima e lo mette a schermo sulla pagina table.ejs */

  let dataJSON = myLibrary.readFile('./data/data.json')
  let person = {
    name: req.body.name,
    nickname: req.body.nickname,
    content: req.body.content,
  }

  myLibrary.addElementToJSON(dataJSON, person)

  res.redirect('/table');
});

app.listen(8080);